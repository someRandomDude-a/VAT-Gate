import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type UserRole = "admin" | "user";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateName: (name: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Simulated user database
const MOCK_USERS = [
  { id: "1", email: "admin@vatguard.com", password: "admin123", name: "Sarah Mitchell", role: "admin" as UserRole },
  { id: "2", email: "user@vatguard.com", password: "user123", name: "James Cooper", role: "user" as UserRole },
];

const simulateLogin = async (email: string, password: string): Promise<{ user: User; token: string } | null> => {
  await new Promise((r) => setTimeout(r, 600));
  const found = MOCK_USERS.find((u) => u.email === email && u.password === password);
  if (!found) return null;
  const { password: _, ...user } = found;
  return { user, token: `Bearer_${btoa(JSON.stringify({ userId: user.id, role: user.role, exp: Date.now() + 86400000 }))}` };
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const savedToken = localStorage.getItem("vatguard_token");
    const savedUser = localStorage.getItem("vatguard_user");
    if (savedToken && savedUser) {
      try {
        setUser(JSON.parse(savedUser));
        setToken(savedToken);
      } catch {
        localStorage.removeItem("vatguard_token");
        localStorage.removeItem("vatguard_user");
      }
    }
  }, []);

  const login = async (email: string, password: string) => {
    const result = await simulateLogin(email, password);
    if (!result) return { success: false, error: "Invalid credentials" };
    setUser(result.user);
    setToken(result.token);
    localStorage.setItem("vatguard_token", result.token);
    localStorage.setItem("vatguard_user", JSON.stringify(result.user));
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("vatguard_token");
    localStorage.removeItem("vatguard_user");
  };

  const updateName = (name: string) => {
    if (!user) return;
    const updated = { ...user, name };
    setUser(updated);
    localStorage.setItem("vatguard_user", JSON.stringify(updated));
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!user, isAdmin: user?.role === "admin", login, logout, updateName }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
